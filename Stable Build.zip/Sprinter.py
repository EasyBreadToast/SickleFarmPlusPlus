import pydirectinput
import time

time.sleep(3)

pydirectinput.PAUSE = 1

for i in range(2):
    pydirectinput.press("shift")

while True:
    pydirectinput.keyDown("shift")
